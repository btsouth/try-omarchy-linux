//go:build linux

package main

import (
	"os"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/godbus/dbus/v5"
)

func TestLinuxGNOMEWaylandSelection(t *testing.T) {
	t.Setenv("WAYLAND_DISPLAY", "wayland-test")
	t.Setenv("XDG_CURRENT_DESKTOP", "ubuntu:GNOME")
	if !linuxGNOMEWayland() {
		t.Fatal("GNOME Wayland did not select the portal")
	}
	t.Setenv("WAYLAND_DISPLAY", "")
	if linuxGNOMEWayland() {
		t.Fatal("GNOME X11 selected the Wayland portal")
	}
}

type testClipboardPortal struct {
	conn     *dbus.Conn
	mu       sync.Mutex
	mime     string
	restored string
	deny     bool
}

const testPortalSession = dbus.ObjectPath("/org/freedesktop/portal/desktop/session/test/clipboard")

func (p *testClipboardPortal) response(path dbus.ObjectPath, results map[string]dbus.Variant) {
	go func() {
		time.Sleep(10 * time.Millisecond)
		_ = p.conn.Emit(path, "org.freedesktop.portal.Request.Response", uint32(0), results)
	}()
}

func (p *testClipboardPortal) CreateSession(options map[string]dbus.Variant) (dbus.ObjectPath, *dbus.Error) {
	path := dbus.ObjectPath("/org/freedesktop/portal/desktop/request/test/create")
	p.response(path, map[string]dbus.Variant{"session_handle": dbus.MakeVariant(string(testPortalSession))})
	return path, nil
}

func (p *testClipboardPortal) SelectDevices(session dbus.ObjectPath, options map[string]dbus.Variant) (dbus.ObjectPath, *dbus.Error) {
	if session != testPortalSession || options["types"].Value() != uint32(2) {
		return "", dbus.MakeFailedError(os.ErrInvalid)
	}
	if value, ok := options["restore_token"]; ok {
		p.mu.Lock()
		p.restored, _ = value.Value().(string)
		p.mu.Unlock()
	}
	path := dbus.ObjectPath("/org/freedesktop/portal/desktop/request/test/devices")
	p.response(path, map[string]dbus.Variant{})
	return path, nil
}

func (p *testClipboardPortal) Start(session dbus.ObjectPath, parent string, options map[string]dbus.Variant) (dbus.ObjectPath, *dbus.Error) {
	path := dbus.ObjectPath("/org/freedesktop/portal/desktop/request/test/start")
	p.mu.Lock()
	deny := p.deny
	p.mu.Unlock()
	if deny {
		p.response(path, map[string]dbus.Variant{"clipboard_enabled": dbus.MakeVariant(false)})
		return path, nil
	}
	p.response(path, map[string]dbus.Variant{"clipboard_enabled": dbus.MakeVariant(true), "restore_token": dbus.MakeVariant("private-consent-token")})
	return path, nil
}

func (p *testClipboardPortal) RequestClipboard(session dbus.ObjectPath, options map[string]dbus.Variant) *dbus.Error {
	if session != testPortalSession {
		return dbus.MakeFailedError(os.ErrInvalid)
	}
	return nil
}

func (p *testClipboardPortal) SetSelection(session dbus.ObjectPath, options map[string]dbus.Variant) *dbus.Error {
	if session != testPortalSession {
		return dbus.MakeFailedError(os.ErrInvalid)
	}
	mimes, _ := options["mime_types"].Value().([]string)
	if len(mimes) != 1 {
		return dbus.MakeFailedError(os.ErrInvalid)
	}
	p.mu.Lock()
	p.mime = mimes[0]
	p.mu.Unlock()
	return nil
}

func (p *testClipboardPortal) SelectionRead(session dbus.ObjectPath, mime string) (dbus.UnixFD, *dbus.Error) {
	if session != testPortalSession || mime != "text/plain" {
		return 0, dbus.MakeFailedError(os.ErrInvalid)
	}
	read, write, err := os.Pipe()
	if err != nil {
		return 0, dbus.MakeFailedError(err)
	}
	go func() {
		_, _ = write.Write([]byte("host portal text"))
		_ = write.Close()
	}()
	return dbus.UnixFD(read.Fd()), nil
}

func (p *testClipboardPortal) Close() *dbus.Error { return nil }

func TestLinuxClipboardPortalPrivateBus(t *testing.T) {
	if os.Getenv("TRYOMARCHY_TEST_PRIVATE_BUS") != "1" || !strings.HasPrefix(os.Getenv("DBUS_SESSION_BUS_ADDRESS"), "unix:") {
		t.Skip("requires a test-owned dbus-run-session bus")
	}
	t.Setenv("XDG_CONFIG_HOME", t.TempDir())
	server, err := dbus.ConnectSessionBus()
	if err != nil {
		t.Fatal(err)
	}
	defer server.Close()
	if reply, err := server.RequestName(linuxPortalDesktop, dbus.NameFlagDoNotQueue); err != nil || reply != dbus.RequestNameReplyPrimaryOwner {
		t.Fatalf("own private portal name: %v, %v", reply, err)
	}
	fake := &testClipboardPortal{conn: server}
	for _, iface := range []string{"org.freedesktop.portal.RemoteDesktop", "org.freedesktop.portal.Clipboard"} {
		if err := server.Export(fake, linuxPortalObject, iface); err != nil {
			t.Fatal(err)
		}
	}
	if err := server.Export(fake, testPortalSession, "org.freedesktop.portal.Session"); err != nil {
		t.Fatal(err)
	}
	c := &linuxClipboard{}
	p, err := linuxPortalClipboardSession(c)
	if err != nil {
		t.Fatal(err)
	}
	c.portal = p
	defer p.close()
	if !c.set(textItem("portal round trip")) {
		t.Fatal("portal rejected guest text selection")
	}
	fake.mu.Lock()
	mime := fake.mime
	fake.mu.Unlock()
	if mime != "text/plain;charset=utf-8" {
		t.Fatalf("portal selection MIME: %q", mime)
	}
	// GNOME 46 emits the MIME array inside a one-field D-Bus struct.
	if err := server.Emit(linuxPortalObject, "org.freedesktop.portal.Clipboard.SelectionOwnerChanged", testPortalSession, map[string]dbus.Variant{"mime_types": dbus.MakeVariant(struct{ Types []string }{[]string{"text/plain"}}), "session_is_owner": dbus.MakeVariant(false)}); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(time.Second)
	for c.sequence() == 0 && time.Now().Before(deadline) {
		time.Sleep(5 * time.Millisecond)
	}
	if c.sequence() == 0 {
		t.Fatal("portal selection notification did not reach the bridge")
	}
	item, ok := c.get()
	if !ok || item.Kind != clipText || string(item.Data) != "host portal text" {
		t.Fatalf("portal read did not reach the guest bridge: %+v, %v", item, ok)
	}
	if token := linuxClipboardRestoreToken(); token != "private-consent-token" {
		t.Fatalf("consent token was not saved: %q", token)
	}
	if err := server.Emit(testPortalSession, "org.freedesktop.portal.Session.Closed", map[string]dbus.Variant{}); err != nil {
		t.Fatal(err)
	}
	deadline = time.Now().Add(time.Second)
	for c.sequence() < 2 && time.Now().Before(deadline) {
		time.Sleep(5 * time.Millisecond)
	}
	if item, ok := c.get(); ok || item.Kind != "" {
		t.Fatalf("revoked portal selection remained available: %+v, %v", item, ok)
	}
	p.close()
	second, err := linuxPortalClipboardSession(&linuxClipboard{})
	if err != nil {
		t.Fatal(err)
	}
	defer second.close()
	fake.mu.Lock()
	restored := fake.restored
	fake.mu.Unlock()
	if restored != "private-consent-token" {
		t.Fatalf("saved consent token was not offered to portal: %q", restored)
	}
	fake.mu.Lock()
	fake.deny = true
	fake.mu.Unlock()
	if _, err := linuxPortalClipboardSession(&linuxClipboard{}); err == nil || !strings.Contains(err.Error(), "did not grant") {
		t.Fatalf("denied portal session did not fail: %v", err)
	}
}
