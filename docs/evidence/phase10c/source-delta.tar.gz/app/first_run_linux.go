//go:build linux

package main

import (
	"fmt"
	"os"
	"path/filepath"
)

// Explicit flags bypass saved choices. Remembered removable locations must
// still exist; never silently create a replacement VM after a drive disappears.
func resolveLinuxDataDirectory(defaultDir, requested string, explicit bool, choose dataLocationChooser) (string, bool, error) {
	if !explicit {
		saved, found, err := loadDataLocationPointer(defaultDir)
		if err != nil {
			return "", false, err
		}
		if found {
			info, err := os.Stat(saved)
			if err != nil {
				return "", false, fmt.Errorf("saved data folder %s is unavailable: %w; reconnect its drive and try again", saved, err)
			}
			if !info.IsDir() {
				return "", false, fmt.Errorf("saved data folder %s is not a directory", saved)
			}
		}
		// Settings saved from the idle home must not silently claim the default
		// storage location. Keep the location choice, and carry those preferences
		// to a newly selected folder before recording its pointer.
		if !found && choose != nil && linuxPrebootSettingsOnly(defaultDir) {
			selected, proceed, err := choose(defaultDir)
			if err != nil || !proceed {
				return selected, proceed, err
			}
			selected, err = validateDataLocationPath(selected)
			if err != nil {
				return "", false, err
			}
			if !pathsEqual(selected, defaultDir) {
				if _, err := os.Stat(settingsPath(selected)); os.IsNotExist(err) {
					prefs, err := loadSettings(settingsPath(defaultDir))
					if err != nil {
						return "", false, err
					}
					if prefs.Share != "" && !prefs.ShareDisabled {
						if _, err := validateLinuxSharedFolder(prefs.Share, selected); err != nil {
							return "", false, fmt.Errorf("selected storage conflicts with the saved shared folder: %w", err)
						}
					}
					if err := saveSettings(settingsPath(selected), prefs); err != nil {
						return "", false, err
					}
				} else if err != nil {
					return "", false, err
				}
				if _, err := os.Stat(filepath.Join(defaultDir, desktopPreferencesFilename)); err == nil {
					if _, err := os.Stat(filepath.Join(selected, desktopPreferencesFilename)); os.IsNotExist(err) {
						prefs, err := loadDesktopPreferences(defaultDir)
						if err != nil {
							return "", false, err
						}
						if err := saveDesktopPreferences(selected, prefs); err != nil {
							return "", false, err
						}
					} else if err != nil {
						return "", false, err
					}
				} else if !os.IsNotExist(err) {
					return "", false, err
				}
				if _, err := os.Stat(filepath.Join(defaultDir, audioPreferencesFilename)); err == nil {
					if _, err := os.Stat(filepath.Join(selected, audioPreferencesFilename)); os.IsNotExist(err) {
						prefs, err := loadAudioPreferences(defaultDir)
						if err != nil {
							return "", false, err
						}
						if err := saveAudioPreferences(selected, prefs); err != nil {
							return "", false, err
						}
					} else if err != nil {
						return "", false, err
					}
				} else if !os.IsNotExist(err) {
					return "", false, err
				}
				if _, err := os.Stat(filepath.Join(defaultDir, storageSettingsFilename)); err == nil {
					if _, err := os.Stat(filepath.Join(selected, storageSettingsFilename)); os.IsNotExist(err) {
						prefs, err := loadStorageSettings(defaultDir)
						if err != nil {
							return "", false, err
						}
						if err := saveStorageSettings(selected, prefs.DiskGiB); err != nil {
							return "", false, err
						}
					} else if err != nil {
						return "", false, err
					}
				} else if !os.IsNotExist(err) {
					return "", false, err
				}
				if _, err := os.Stat(filepath.Join(defaultDir, linuxExperiencePreferencesFilename)); err == nil {
					if _, err := os.Stat(filepath.Join(selected, linuxExperiencePreferencesFilename)); os.IsNotExist(err) {
						prefs, err := loadLinuxExperiencePreferences(defaultDir)
						if err != nil {
							return "", false, err
						}
						if err := saveLinuxExperiencePreferences(selected, prefs); err != nil {
							return "", false, err
						}
					} else if err != nil {
						return "", false, err
					}
				} else if !os.IsNotExist(err) {
					return "", false, err
				}
				if _, err := os.Stat(filepath.Join(defaultDir, launchPreferencesFilename)); err == nil {
					if _, err := os.Stat(filepath.Join(selected, launchPreferencesFilename)); os.IsNotExist(err) {
						prefs, err := loadLaunchPreferences(defaultDir)
						if err != nil {
							return "", false, err
						}
						if err := saveLaunchPreferences(selected, prefs); err != nil {
							return "", false, err
						}
					} else if err != nil {
						return "", false, err
					}
				} else if !os.IsNotExist(err) {
					return "", false, err
				}
				if err := saveDataLocationPointer(defaultDir, selected); err != nil {
					return "", false, err
				}
			}
			return selected, true, nil
		}
	}
	return resolveStandardDataDirectory(defaultDir, requested, explicit, choose != nil, choose)
}

func linuxPrebootSettingsOnly(dir string) bool {
	entries, err := os.ReadDir(dir)
	if err != nil {
		return false
	}
	found := false
	for _, entry := range entries {
		switch entry.Name() {
		case settingsFileName:
			found = true
		case desktopPreferencesFilename, audioPreferencesFilename, storageSettingsFilename, linuxExperiencePreferencesFilename, launchPreferencesFilename, "diagnostics", "portable-host":
		default:
			return false
		}
	}
	return found
}

func (u *progressUI) chooseLocation(defaultDir string) (string, bool, error) {
	status := ""
	for {
		value, err := u.window.ask(setupContext(), linuxSetupState{Prompt: "location", Path: defaultDir, Status: status})
		if err != nil {
			return "", false, err
		}
		selected := defaultDir
		if value != "default" {
			selected, err = validateDataLocationPath(value)
			if err == nil && filepath.Base(selected) != "try-omarchy" {
				selected = filepath.Join(selected, "try-omarchy")
			}
		}
		if err == nil {
			var selectable bool
			selectable, err = linuxDataLocationSelectable(selected, defaultDir)
			if err == nil && !selectable {
				err = fmt.Errorf("%s already contains other files or an incomplete installation. Choose an empty folder, or use -dir to resume that installation", selected)
			}
		}
		if err == nil {
			prefs, loadErr := loadSettings(settingsPath(defaultDir))
			if loadErr != nil {
				err = loadErr
			} else if prefs.Share != "" && !prefs.ShareDisabled {
				_, err = validateLinuxSharedFolder(prefs.Share, selected)
			}
		}
		if err == nil {
			err = ensureDataDirectoryWritable(selected)
		}
		if err == nil {
			return selected, true, nil
		}
		status = "Cannot use that folder: " + err.Error()
	}
}

func linuxDataLocationSelectable(selected, defaultDir string) (bool, error) {
	// Saving preferences on the idle home writes only settings.json. That
	// folder is still an unclaimed first-run location.
	if pathsEqual(selected, defaultDir) && linuxPrebootSettingsOnly(defaultDir) {
		return true, nil
	}
	return standardDataDirectorySelectable(selected)
}

// An existing disk without a mode predates this flow. Leave its account alone.
// Fresh disks get a new choice; interrupted setup resumes its saved choice.
func chooseLinuxProvisionMode(cfg *config, explicit bool, choose func() (string, error)) error {
	if !cfg.fresh && !explicit {
		if mode, found := readProvisionMode(cfg.dir); found {
			cfg.instant = mode == provisionModeInstant
			return nil
		}
	}
	if !cfg.fresh {
		if _, err := os.Stat(cfg.disk); err == nil {
			return nil
		} else if !os.IsNotExist(err) {
			return err
		}
	}
	mode := provisionModePersonal
	if cfg.instant {
		mode = provisionModeInstant
	}
	if !explicit && choose != nil {
		var err error
		mode, err = choose()
		if err != nil {
			return err
		}
	}
	if err := writeProvisionMode(cfg.dir, mode); err != nil {
		return err
	}
	cfg.instant = mode == provisionModeInstant
	return nil
}
