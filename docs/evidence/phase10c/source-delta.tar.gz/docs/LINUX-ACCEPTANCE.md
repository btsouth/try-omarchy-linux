# Private Linux acceptance

All work remains local. No workflow, branch, bundle, or guest image is published.

Use [Linux release gates](LINUX-RELEASE-GATES.md) for the complete end-user
lifecycle checklist and next work, alongside the checks in this document.

## Repeatable checks

Run `scripts/linux/check.sh /data/try-omarchy-checks` for Linux race tests,
Linux vet, Windows vet, and Windows cross-build/test compilation. Native Windows
tests run only in the repository's Windows CI job.

Build with `runtime-build/linux/build-flatpak.sh /data/try-omarchy-flatpak`.
The build container and downloaded sources are pinned. Module builds have no
network access; the builder downloads authenticated source archives first.
The output includes the bundle and its SHA256 digest. This is not a claim of
bit-for-bit reproducibility across different SDK revisions.

Install the candidate bundle in the test account, then run:

```sh
scripts/linux/smoke-flatpak.sh /data/try-omarchy-smoke \
  http://127.0.0.1:18090 TRUSTED_SHA256SUMS_DIGEST
```

The script creates an invisible omabox, blocks host session services and audio,
uses a new VM directory and temporary SSH key, checks guest service readiness,
saves a screenshot, and requests a clean guest shutdown. Inspect the screenshot;
SSH alone does not establish visual acceptance. The output directory is retained.
Use a fresh directory for each run. Do not run alongside another launcher.

`runtime-build/linux/ci/private-acceptance.yml` is a disabled workflow template
for a disposable runner with KVM and omabox. It deliberately lives outside
`.github/workflows`. Enabling or publishing it requires a separate decision.

## Product acceptance before publication

The current candidate has runtime/integration evidence, not feature-parity
sign-off. Complete the outstanding [product phases](LINUX-PLAN.md) and review
[Linux parity](LINUX-PARITY.md) before treating it as release-ready. Ordinary
use must work through the GUI with the intended Linux guest, without test-only
release arguments. Resolve serious known issues and have Brandon explicitly
accept any remaining parity gaps. Publication always needs his separate request.

## Phase 8A checkpoint

The pre-boot home and revised Settings form are local source changes. Focused
launcher tests cover direct-start precedence, idle-home read-only behavior,
Settings save/cancel preservation and carrying new-install preferences to a
selected storage folder. The exact GTK build, isolated screenshots and
remaining visual checks are recorded in the Phase 8 evidence report.

This checkpoint does not settle first-run guest readiness, normal Linux guest
selection, recovery, portal file grants, broader parity or physical acceptance.

## Phase 8B checkpoint

The Linux launcher now selects a pinned private Linux guest on ordinary launch
without release arguments. The default URL is local loopback and exists only for
private acceptance. The Windows release defaults remain separate. Guest patch
0101 reports desktop readiness after an Omarchy graphical session, monitor and
stable background/bar surfaces are present. Compatibility revision 39 updates
the service on existing private disks. Setup remains open through earlier QMP
and userspace-ready signals. The host reports a timeout or early VM exit instead
of silently closing setup. Local first-run and returning-boot checks reached the desktop in
omabox; see the exact artifact identities and limits in the [Phase 8B evidence](evidence/LINUX-SOL-PHASE8B-2026-09-26.md).

Before publication, replace the loopback fixture with an approved public Linux
artifact plan and independent checksum pin, then repeat fresh and returning
boots against that exact candidate. The Phase 8B checkpoint does not cover the
remaining product parity, recovery, external portal and physical gates below.

## Release gates

- Verify the exact bundle and guest checksums, not an earlier build.
- Boot a fresh disk and migrate a saved disk without losing personal files.
- Check setup cancellation, resume, folder grants after restart, account choice,
  close confirmation, and failure of the setup helper.
- Check clipboard text, PNGs and files in both directions, reconnection, transfer
  cancellation, and folder/drop access under the Flatpak sandbox.
- Check GNOME, KDE Wayland, an X11 desktop, and Omarchy. On GNOME Wayland,
  verify the Remote Desktop portal consent prompt, grant, two-way clipboard,
  denial, revocation and token restore on the installed candidate.
- Check scaling, keyboard overrides, tray and guest Settings entry, and audio
  device loss/recovery in isolated sessions.
- Run physical laptop, microphone, speakers, suspend/resume and real multi-monitor
  checks only when Brandon asks. These remain separate from automated acceptance.
- Confirm the main checkout is untouched and nothing was pushed or published.

## Outstanding targeted acceptance

Live external-file drops that require sandbox permission acquisition and a
portal FileTransfer grant roundtrip remain to be checked. The final QEMU
small-window sizing fix passed Intel, NVIDIA omabox and X11 checks; rerun GNOME
and KDE against the exact final bundle before release. Earlier matrix results
and artifact identities are in [integration evidence](evidence/LINUX-INTEGRATION-2026-09-26.md).

## Current limits

The host keyboard layout follows exposed `XKB_DEFAULT_LAYOUT` and
`XKB_DEFAULT_VARIANT` values, or `-keyboard`. It does not monitor desktop layout
switches. `-keyboard keep` preserves the guest choice. `-scale keep` preserves
the prior guest scale policy; numeric scale overrides are available.

Audio defaults to PipeWire, with silent fallback if startup fails. Named routes
and microphone disable are available through flags. Physical playback remains
unverified. LAN forwarding, camera capture, battery integration, and Linux
backup/restore UI remain Phase 9 and 10 work. Their physical acceptance is
separate from isolated functional checks.
