# Linux product parity, 2026-09-27

Status: private engineering candidate, not ready for publication. Phase 8A
added the pre-boot home and preference controls. Phase 8B pairs it with a
private Linux guest and waits for the usable desktop. The Phase 8B correction
and first Phase 9 slice have separate local evidence reports. Physical tests
remain deferred.

The public release references currently resolve to Windows
[v0.4.0](https://github.com/omacom/try-omarchy-windows/releases/tag/v0.4.0) and Mac
[v0.4.1](https://github.com/omacom/try-omarchy/releases/tag/v0.4.1). The
[Mac main README](https://github.com/omacom/try-omarchy/blob/main/README.md) also
provides the current implementation target; main can contain work newer than
the released app. This is not a claim that every main-branch feature has shipped
or passed hardware acceptance. The older MAC-PARITY.md remains historical
Windows/Mac evidence and should not determine current release status by itself.

| Area | Linux today | Work before near parity |
| --- | --- | --- |
| Identity | Same Omarchy SVG icon, Try Omarchy title, desktop entry and tray identity; Phase 8A adds version/help in the idle home | Accurate metadata, full visual acceptance and broader product polish |
| First run | GTK location, trial/personal account, shared folder, download progress and cancellation; private Phase 8B guest reached the desktop without release flags | Broader error/recovery paths, portal grants, accessibility and desktop matrix |
| Returning user | Idle home offers Launch, Settings and saved disk status; the private disk booted again without redownloading | Broader startup/display preferences and desktop matrix |
| Settings | Automatic or bounded manual RAM/CPU controls, rendering, sharing, fullscreen launch and microphone access, with saved choices | GUI audio routes, broader display, input, networking and storage controls; broader accessibility review |
| Core VM | KVM, GPU/OpenGL, conditional Venus, CPU fallback, reboot/shutdown and RAM reclamation | Broader workload, graphics and long-running acceptance |
| Clipboard/files | Text, PNG and file roundtrips on tested Wayland/X11; selected shared folder; GNOME consented portal bridge in current source | Real GNOME consent and clipboard roundtrips, external-drop and FileTransfer grants, cancellation and reconnection |
| Audio | PipeWire playback/recording and dummy-device recovery; microphone GUI choice and route flags | User-facing device choices and live switching parity; physical acceptance later |
| Camera and battery | No Linux camera capture or host battery feed | Linux integrations and eventual physical acceptance |
| Input/display | Focused keyboard capture, simulated scale following, environment/flag keyboard layout, fullscreen GUI choice | Layout switches, gestures, broader monitor UX and physical coverage |
| Networking | NAT and loopback port/SSH flags | GUI controls and a deliberate LAN/bridge scope decision |
| Recovery/updates | Shared foundations, retained disk on fresh reset, private test scripts | Linux GUI backup/restore/reset/move, diagnostics, update/rollback and install lifecycle |
| Other host integration | No Linux approved-host-app launcher or USB management UI | Inventory Windows/Mac behavior and explicitly decide Linux scope |
| Distribution | Locally built/installed Flatpak pins a Linux guest served on local loopback | Public artifact location and pin policy, private update rehearsal |

Phase 3 through 7 screenshots: `/data/try-omarchy-linux-spike/phase3-flow/devbox-account-final.png`
and `/data/try-omarchy-linux-spike/phase5/kde-settings.png`. They show the prior
GTK form with technical text fields. Phase 8A replaces those source controls;
its exact visual evidence and remaining gaps belong in the Phase 8 report.

Phase 8B selects a pinned private Linux guest from local loopback on ordinary
launch, rather than the shared Windows release defaults. This is a test fixture,
not a public distribution channel. Successful earlier Linux acceptance used the
private guest with patches 0096 through 0100 and explicit release/checksum
arguments. The new desktop-ready guest patch is 0101. The exact paired runtime
result is in the Phase 8B evidence. A public Linux artifact plan remains a
release gate.

Near parity means comparable everyday outcomes and a usable GUI, not identical
platform APIs. Mac Touch ID and Windows Hello cannot be copied verbatim to Linux;
any equivalent or deferral needs an explicit scope decision. Likewise, platform
restrictions do not automatically excuse missing core workflows. Keep the GNOME
clipboard workflow open until consent and two-way roundtrips pass on the installed package.

The plan now has phases 8 through 11 for product polish, everyday parity,
installation/recovery/update work and exact-candidate hardening. Nothing should
be published just because phases 3 through 7 have implementation evidence.

## Dated comparison for the private candidate

Checked 2026-09-27 against the published [Windows v0.4.0
release](https://github.com/omacom/try-omarchy-windows/releases/tag/v0.4.0),
its [tagged README](https://raw.githubusercontent.com/omacom/try-omarchy-windows/v0.4.0/README.md),
and the published [Mac v0.4.1
release](https://github.com/omacom/try-omarchy/releases/tag/v0.4.1) and
[tagged README](https://raw.githubusercontent.com/omacom/try-omarchy/v0.4.1/README.md).
The tagged README is a description of shipped source, not a fresh physical
acceptance result. The Windows v0.4.0 notes add Precision Touchpad pinch,
Ctrl+Alt+End and a guest package refresh. The Mac v0.4.1 notes fix a macOS 15
launch crash and theme/DNS password dialog. Newer main-branch work is a separate
target and is not counted as a released feature.

| End-user outcome | Windows v0.4.0 | Mac v0.4.1 | Linux private work on 2026-09-27 |
| --- | --- | --- | --- |
| Normal install and first desktop | Signed launcher, verified download and guided first run | Signed DMG and app, guided guest start | Private Flatpak and guest reached a personal desktop; normal distribution route and full install lifecycle still open |
| Audio and microphone | Live route switching; microphone switch at next start | Live route switching in guest | GUI route choices and microphone switch in Phase 9B bundle; no live switching; private audio recovery and physical devices still need acceptance |
| Camera and battery | Camera controls and host battery feed | Portal-style host consent and on-demand virtual camera | Camera guest bridge reports unavailable; Linux battery sysfs source added after Phase 9C snapshot, fixture tested, packaged and VM acceptance pending |
| Clipboard and files | Two-way text/image/file clipboard, drop and sharing | Two-way text/image clipboard and chosen shared folder | Prior Wayland/X11 bridge checks; GNOME portal bridge and external grant UI in source, with installed GNOME consent and FileTransfer round trips still open |
| Display and input | Fullscreen monitor choice, capture release, Precision Touchpad pinch | Native resize and HiDPI updates | Fullscreen and scale/layout preferences; packaged personal desktop booted at 150% and German layout; multi-monitor and gestures open |
| Networking and host integration | NAT, SSH/port forwards, approved Windows app launch and experimental portable USB storage | NAT/bridge and SSH; Touch ID guest sudo | NAT and SSH GUI source in Phase 9C build; LAN, approved host-app launch, USB device access and host authentication outcome not implemented |
| Data and recovery | GUI backup, reset, move, diagnostics, signed update recovery | VM location and reset, Mac update path | Existing backup/restore engine and Linux guest pin; no accepted Linux GUI recovery, relocation or update lifecycle |

Brandon chose consented automatic GNOME Wayland clipboard synchronization on
2026-09-27. The source now creates a [Remote Desktop
session](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.RemoteDesktop.html)
with pointer permission because GNOME disables Share for a clipboard-only
request, requests the [Clipboard
portal](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.Clipboard.html)
before Start, requires desktop consent and stores a single-use restore token
when offered. It does not send remote input events. This broader GNOME consent
must be clear in the installed workflow. Denial and revocation have visible messages. The private D-Bus
protocol regression passes. A real GNOME Wayland permission prompt and
text/image/file roundtrips on the installed Flatpak remain an acceptance gate.
