//go:build !windows

package main

import (
	"os"
	"syscall"
)

func openBackupDisk(path string) (*os.File, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	if err = syscall.Flock(int(f.Fd()), syscall.LOCK_EX|syscall.LOCK_NB); err != nil {
		if portalErr := portalBackupDiskLockFallback(path, f, err); portalErr != nil {
			f.Close()
			return nil, portalErr
		}
	}
	return f, nil
}
